#include<stdio.h>
#include<conio.h>
main()
{
/*
5 4 3 2 1
  5 4 3 2
    5 4 3
      5 4
	5

*/
int i,j,k,count=1;
clrscr();

for(i=1;i<=4;i++)
{
   for(k=5;k>6-i;k--)
   {
     printf("  ");

   }
   for(j=4;j>=i;j--)
   {
      printf("%d ",count);
      count++;
   }
   printf("\n");

}
getch();
}