#include<stdio.h>
#include<conio.h>
main()
{
/*
	    1
	  2 1
	3 2 1
      4 3 2 1
    5 4 3 2 1
*/
int i,j,k;
clrscr();

for(i=1;i<=5;i++)
{
   for(k=5;k>i;k--)
   {
     printf("  ");

   }
   for(j=i;j>=1;j--)
   {
      printf("%d ",j);
   }
   printf("\n");

}
getch();
}