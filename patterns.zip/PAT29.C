

#include<stdio.h>
#include<conio.h>
main()
{
/*
print N to 1

*/
int i,j,k,rows;
clrscr();
printf("Enter rows");
scanf("%d",&rows);

for(i=rows;i>=1;i--)
{
   for(k=rows;k>i;k--)
   {
     printf("  ");

   }
   for(j=i;j>=1;j--)
   {
      printf("%d ",j);
   }
   printf("\n");

}
getch();
}