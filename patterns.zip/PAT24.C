#include<stdio.h>
#include<conio.h>
main()
{
/*
1 1 1 1 1
  2 2 2 2
    3 3 3
      4 4
	5
*/
int i,j,k;
clrscr();

for(i=1;i<=5;i++)
{
   for(k=5;k>6-i;k--)
   {
     printf("  ");

   }
   for(j=i;j<=5;j++)
   {
      printf("%d ",i);
   }
   printf("\n");

}
getch();
}